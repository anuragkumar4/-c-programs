﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment11
{
    class Program
    {

        static string word;
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the word");
            word = Console.ReadLine();
            char[] array = word.ToCharArray();
            Array.Reverse(array);
            string text=new String(array);
            Console.WriteLine(text);
            //if(str.Equals(word))
            //    Console.WriteLine("It is palindrome");
            //else
            //    Console.WriteLine("It is an anagram");
            Console.ReadLine();
        }
    }
}
