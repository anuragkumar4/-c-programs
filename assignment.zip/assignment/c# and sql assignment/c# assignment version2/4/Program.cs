﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 0;
            try
            {
                a = getint();
            }
            catch (FormatException e)
            {

                Console.WriteLine(e.Message);
            }
            int result=0;
            while (a != 0)
            {
                int rem = a % 10;
                result += rem;
                a /= 10;
            }
            Console.WriteLine(result);
            Console.ReadLine();
        }
        public static int getint()
        {
            Console.WriteLine("Enter the number");
            int choice;
            if (int.TryParse(Console.ReadLine(), out choice))
                return choice;
            else
                throw new FormatException();
        }
    }
}
