﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            int result = 0;
            int x = int.Parse(Console.ReadLine());
            if (x == 0)
                result = 1;
            while (x != 0)
            {
                int rem = x % 10;
                result = result*10 + rem;
                x /= 10;
            }
            Console.WriteLine(result);
            Console.ReadLine();
        }
    }
}
