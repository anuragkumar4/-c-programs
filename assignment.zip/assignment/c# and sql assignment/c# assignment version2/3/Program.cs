﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment2
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Enter the number of factorials you want");
            int x;
            if (int.TryParse(Console.ReadLine(), out x))
            {
                for (int i = 0; i < x; i++)
                {
                    int fact = 1;
                    for (int j = x; j > 1; j--)
                    {
                        fact = fact * j;
                    }
                    Console.WriteLine("The number is {0} and its factorial is {1}", i, fact);
                }
            }
            else
                Console.WriteLine("Enter a valid number");
            Console.ReadLine();
        }
    }
}
