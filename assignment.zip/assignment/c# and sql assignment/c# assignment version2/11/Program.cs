﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment12
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] a = new int[10, 10];
            for(int i=0;i<10;i++)
            {
                for (int j = 10; j> i; j--)
                {
                    Console.Write(" ");
                }
                for (int k = 0; k < i; k++)
                {
                    if(k==0|i==k)
                    
                        a[i, k] = 1;
                    

                    else
                    {
                        a[i, k] = a[i - 1, k] + a[i - 1, k - 1];
                    }
                    Console.Write(" "+a[i,k]);
                }
                Console.ReadLine();

            }
        }
    }
}
