﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment15
{
    class Program
    {
        static void Main(string[] args)
        {
            
              Console.WriteLine("Enter the total numbers");
                int num = int.Parse(Console.ReadLine());
            int choice = 0;
                string[] menuOption = { "1. Ascending Order", "2. Descending Order" };
                foreach (var item in menuOption)
                {
                    Console.WriteLine(item);
                }
            Console.WriteLine("Enter the choice");
            try
            {
                 choice = getint();
            }
            catch (FormatException e)
            {

                Console.WriteLine(e.Message);
            }

                int[] arr = new int[num];
                Console.WriteLine("Enter numbers for array");
                for (int i = 0; i < num; i++)
                {
                try
                {
                    arr[i] = getint();
                }
                catch (FormatException e)
                {

                    Console.WriteLine(e.Message);
                }
            }

                switch (choice)
                {
                    case 1:
                    Stopwatch watch = new Stopwatch();
                    watch.Start();
                    BubbleSort(arr);
                    watch.Stop();
                    TimeSpan ts= watch.Elapsed;
                    Console.WriteLine(ts);
                    Stopwatch watch1 = new Stopwatch();
                    watch1.Start();
                    InsertionSort(arr);
                    watch1.Stop();
                    TimeSpan ts4 = watch1.Elapsed;
                    Console.WriteLine(ts4);
                    break;
                    case 2:
                    Stopwatch watch3 = new Stopwatch();
                    watch3.Start();
                    BubbleSortd(arr);
                    watch3.Stop();
                    TimeSpan ts2 = watch3.Elapsed;
                    Console.WriteLine(ts2);
                    Stopwatch watch4 = new Stopwatch();
                    watch4.Start();
                    InsertionSortd(arr);
                    watch4.Stop();
                    TimeSpan ts3 = watch4.Elapsed;
                    Console.WriteLine(ts3);
                    break;
                    default:
                        Console.WriteLine("Invalid Value");
                        break;
                }
                //time taken
                //number of operations done
                Console.ReadLine();
            }
            private static void InsertionSort(int[] arr)
            {
                for (int i = 1; i < arr.Length; i++)
                {
                    int item = arr[i];
                    int ins = 0;
                    for (int j = i - 1; j >= 0 && ins != 1;)
                    {
                        if (item < arr[j])
                        {
                            arr[j + 1] = arr[j];
                            j--;
                            arr[j + 1] = item;
                        }
                        else ins = 1;
                    }
                }

                Console.WriteLine("The array after Insertion sort:");

                for (int i = 0; i < arr.Length; i++)
                {
                    Console.WriteLine(arr[i]);

                }
            }
            private static void InsertionSortd(int[] arr)
            {
                for (int i = 1; i > arr.Length; i++)
                {
                    int item = arr[i];
                    int ins = 0;
                    for (int j = i - 1; j >= 0 && ins != 1;)
                    {
                        if (item < arr[j])
                        {
                            arr[j + 1] = arr[j];
                            j--;
                            arr[j + 1] = item;
                        }
                        else ins = 1;
                    }
                }

                Console.WriteLine("The array after Insertion sort:");

                for (int i = 0; i < arr.Length; i++)
                {
                    Console.WriteLine(arr[i]);

                }
            }

            private static void BubbleSort(int[] arr)
            {
                for (int i = arr.Length - 1; i > 0; i--)
                {
                    for (int j = 0; j <= i - 1; j++)
                    {
                        if (arr[j] > arr[j + 1])
                        {
                            int temp = arr[j];

                            arr[j] = arr[j + 1];
                            arr[j + 1] = temp;
                        }
                    }
                }
                Console.WriteLine("The array after Bubble sort:");

                for (int i = 0; i < arr.Length; i++)
                {
                    Console.WriteLine(arr[i]);

                }
            }
            private static void BubbleSortd(int[] arr)
            {
                for (int i = arr.Length - 1; i > 0; i--)
                {
                    for (int j = 0; j <= i - 1; j++)
                    {
                        if (arr[j] < arr[j + 1])
                        {
                            int temp = arr[j];

                            arr[j] = arr[j + 1];
                            arr[j + 1] = temp;
                        }
                    }
                }
                Console.WriteLine("The array after Bubble sort:");

                for (int i = 0; i < arr.Length; i++)
                {
                    Console.WriteLine(arr[i]);

                }
            }
        public static int getint()
        {
            int choice;
            if (int.TryParse(Console.ReadLine(), out choice))
                return choice;
            else
                throw new FormatException();
        }
        }
    }

