﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystem
{
    class SavingsAccount : Account, ITransaction
    {
        private int MaxAmountPerDay = 50000;

        public string fromAccount
        {
            get
            {
                return fromAccount;
            }

            set
            {
                fromAccount = value;
            }
        }

        public string toAccount
        {
            get
            {
                return toAccount;
            }

            set
            {
                toAccount = value;
            }
        }

        public string TypeofAccount
        {
            get
            {
                return TypeofAccount;
            }

            set
            {
                TypeofAccount = "SAVINGS ACCOUNT";
            }
        }

        public void GetAccountDetails()
        {
            Console.WriteLine($"Account holder name--->{this.username}");
            Console.WriteLine($"Account type is------->{this.TypeofAccount}");
            Console.WriteLine($"Account number is----->{this.accno}");
            Console.WriteLine($"Balance is------------>{this.balance}");
        }

        public override void deposit()
        {
            Console.WriteLine("Enter the amount to be deposited");
            int amt = int.Parse(Console.ReadLine());
            if (amt > MaxAmountPerDay)
            {
                throw new InvalidOption("sorry you have exceeded the limit of amount that can be deposited");
            }
            else
            {
                this.balance += amt;
                Console.WriteLine("Amount has been deposited successfully");
                Console.ReadLine();
            }
        }

        public override void withdrawl()
        {
            Console.WriteLine("Enter the amount to be withdrawn");
            int amt = int.Parse(Console.ReadLine());
            if (amt < (this.balance - 1000))
            {
                this.balance -= amt;
                Console.WriteLine("Amount has been withdrawn successfully");
            }
            else
                throw new InvalidOption("Sorry insufficient balance");
        }
        public void TransferAmount()
        {
            Console.WriteLine("Enter to account number");
            this.toAccount = Console.ReadLine();
            this.fromAccount = this.accno;
            foreach (var item in Program.slist)
            {
                if (item.accno == this.toAccount)
                {
                    Console.WriteLine("Enter the amount to be transfered");
                    int b = int.Parse(Console.ReadLine());
                    if (b < (this.balance - 1000))
                    {
                        this.balance -= b;
                        item.balance += b;
                        break;
                    }
                    else
                        throw new InvalidOption("Enter valid account number");
                }
            }
        }
        public static void GetRateofInterest()
        {
            Console.WriteLine("The interest for savings account is 4% per annum with a minimum balance of 25,000 rupees");
        }
        public override void removeAcc()
        {
            Program.slist.Remove(this);
        }
        public static SavingsAccount findAccount()
        {
            string a = Console.ReadLine();
            foreach (var item in Program.slist)
            {
                if (item.accno == a)
                {
                    return item;
                }
            }
            return null;
        }
    }
 }

