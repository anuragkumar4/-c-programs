﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystem
{
    class CurrentAccount : Account,ITransaction
    {
        private int MinimumBalanceRequired = 10000;
        public string fromAccount
        {
            get
            {
                return fromAccount;
            }

            set
            {
                fromAccount = value;
            }
        }

        public string toAccount
        {
            get
            {
                return toAccount;
            }

            set
            {
                toAccount = value;
            }
        }

        public string TypeofAccount
        {
            get
            {
                return TypeofAccount;
            }

            set
            {
                TypeofAccount = "CURRENT ACCOUNT";
            }
        }

        public void GetAccountDetails()
        {
            Console.WriteLine($"Account holder name--->{this.username}");
            Console.WriteLine($"Account number is----->{this.accno}");
            Console.WriteLine($"Balance is------------>{this.balance}");
            Console.WriteLine($"Account type is------->{this.TypeofAccount}");
        }
        public override void deposit()
        {
            Console.WriteLine("Enter the amount to be deposited");
            int amt = int.Parse(Console.ReadLine());
            this.balance += amt;
            Console.WriteLine("Amount has been deposited successfully");
        }

        public override void withdrawl()
        {
            Console.WriteLine("Enter the amount to be withdrawn");
            int amt = int.Parse(Console.ReadLine());
            if (amt < (this.balance-MinimumBalanceRequired))
             {
                this.balance -= amt;
                Console.WriteLine("Amount has been withdrawn successfully");
             }
             else
                throw new InvalidOption("Sorry insufficient balance");
        }
        public static void GetRateofInterest()
        {
            Console.WriteLine("For 1 year the rate of interest is 1.50% per annum");
            Console.WriteLine("For 2 year the rate of interest is 2.50% per annum");
            Console.WriteLine("For 3 year the rate of interest is 3.50% per annum");
            Console.WriteLine("For 4 year the rate of interest is 4.50% per annum");
        }
        public override void removeAcc()
        {
            Program.alist.Remove(this);
        }
        public void TransferAmount()
        {
            Console.WriteLine("Enter to account number");
            this.toAccount = Console.ReadLine();
            this.fromAccount = this.accno;
            foreach (var item in Program.slist)
            {
                if (item.accno == this.toAccount)
                {
                    Console.WriteLine("Enter the amount to be transfered");
                    int b = int.Parse(Console.ReadLine());
                    if (b < (this.balance - MinimumBalanceRequired))
                    {
                        this.balance -= b;
                        item.balance += b;
                        break;
                    }
                    else
                        throw new InvalidOption("sorry no sufficient balance");
                }
            }
        }
        public static CurrentAccount findAccount()
        {
            Console.WriteLine("Enter the account number");
            string a = Console.ReadLine();
            foreach (var item in Program.alist)
            {
                if (item.accno == a)
                {
                    return item;
                }
            }
            return null;
        }
    }
}
