﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankingSystem
{
    class Program
    {
        static public List<SavingsAccount> slist = new List<SavingsAccount>();
        static public List<CurrentAccount> alist = new List<CurrentAccount>();
        static void Main(string[] args)
        {
            int choice;
            int option;
            Console.WriteLine("Welcome to our bank");
            while (true)
            {
                while (true)
                {
                    while (true)
                    {
                        Console.WriteLine("1.Savings account \n2.Current Account");
                        if (int.TryParse(Console.ReadLine(), out choice))
                            break;
                    }
                    try
                    {
                        if (choice == 1 || choice == 2)
                        {
                            Console.WriteLine("1.Create account\n2.Edit Account\n3.Withdraw\n4.Deposit\n5.Remove Account\n6.Amount transfer\n7.Account details\n8.To know the interest rates");
                            break;
                        }
                        else throw new InvalidOption("Invalid Option. Please enter a valid option");
                    }
                    catch (InvalidOption e)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine(e.getmessage());
                        Console.ResetColor();
                    }
                }
                while (true)
                {
                    Console.WriteLine("Enter the option");
                    while (true)
                    {
                        if (int.TryParse(Console.ReadLine(), out option))
                            break;
                    }
                    try
                    {
                        if (option > 7 && option < 1)
                        {
                            throw new InvalidOption("Invalid Option. Please enter a valid option");
                        }
                        else break;
                    }
                    catch (InvalidOption e)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        e.getmessage();
                        Console.ResetColor();
                    }
                }
                if (choice == 1)
                {
                    SavingsAccount s1;
                    switch (option)
                    {
                        case 1:
                            try
                            {
                                slist.Add(new SavingsAccount());
                            }
                            catch (InvalidOption e)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine(e.getmessage());
                                Console.ResetColor();
                            }
                            break;
                        case 2:
                            Console.WriteLine("Enter the account number");
                            s1 = SavingsAccount.findAccount();
                            if (s1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                s1.editAcc();
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("Your account has been edited successflly");
                                Console.ResetColor();
                            }
                            break;
                        case 3:
                            Console.WriteLine("Enter your account number");
                            s1 = SavingsAccount.findAccount();
                            if (s1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                try
                                {
                                    s1.withdrawl();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Amount has been withdrawn");
                                    Console.ResetColor();
                                }
                                catch (InvalidOption e)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine(e.getmessage());
                                    Console.ResetColor();
                                }
                            }
                            break;
                        case 4:
                            Console.WriteLine("Enter your account number");
                            s1 = SavingsAccount.findAccount();
                            if (s1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                try
                                {
                                    s1.deposit();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("The amount has been deposited successfully");
                                    Console.ResetColor();
                                }
                                catch (InvalidOption e)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine(e.getmessage());
                                    Console.ResetColor();
                                }
                            }
                            break;
                        case 5:
                            Console.WriteLine("Enter your account number");
                            s1 = SavingsAccount.findAccount();
                            if (s1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                s1.removeAcc();
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("The account has been removed successfully");
                                Console.ResetColor();
                            }
                            break;
                        case 6:
                            Console.WriteLine("Enter from account number");
                            s1 = SavingsAccount.findAccount();
                            if (s1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                try
                                {
                                    s1.TransferAmount();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("The amount has been transfered successfully");
                                    Console.ResetColor();
                                }
                                catch (InvalidOption e)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine(e.getmessage());
                                    Console.ResetColor();
                                }
                            }
                            break;
                        case 7:
                            Console.WriteLine("Enter your account number");
                            s1 = SavingsAccount.findAccount();
                            if (s1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                s1.GetAccountDetails();
                            }
                            break;
                        case 8:
                            SavingsAccount.GetRateofInterest();
                            break;
                    }
                }
                else if (choice == 2)
                {
                    CurrentAccount c1;
                    switch (option)
                    {
                        case 1:
                            try
                            {
                                alist.Add(new CurrentAccount());
                            }
                            catch (InvalidOption e)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine(e.getmessage());
                                Console.ResetColor();
                            }
                            break;
                        case 2:
                            Console.WriteLine("Enter your account number");
                            c1 = CurrentAccount.findAccount();
                            if (c1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                c1.editAcc();
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("changes have been made sucessfully");
                                Console.ResetColor();
                            }
                            break;
                        case 3:
                            Console.WriteLine("Enter your account number");
                            c1 = CurrentAccount.findAccount();
                            if (c1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                try
                                {
                                    c1.withdrawl();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("Amouny has been withdrawn successfully");
                                    Console.ResetColor();
                                }
                                catch (InvalidOption e)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine(e.getmessage());
                                    Console.ResetColor();
                                }
                            }
                            break;
                        case 4:
                            Console.WriteLine("Enter your account number");
                            c1 = CurrentAccount.findAccount();
                            if (c1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                try
                                {
                                    c1.deposit();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("The amount has been deposited successfully");
                                    Console.ResetColor();
                                }
                                catch (InvalidOption e)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine(e.getmessage());
                                    Console.ResetColor();
                                }
                            }
                            break;
                        case 5:
                            Console.WriteLine("Enter your account number");
                            c1 = CurrentAccount.findAccount();
                            if (c1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                c1.removeAcc();
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("The account has been removed successfully");
                                Console.ResetColor();
                            }
                            break;
                        case 6:
                            Console.WriteLine("Enter from account number");
                            c1 = CurrentAccount.findAccount();
                            if (c1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ResetColor();
                            }
                            else
                            {
                                try
                                {
                                    c1.TransferAmount();
                                    Console.ForegroundColor = ConsoleColor.Green;
                                    Console.WriteLine("The amount has been transfered successfully");
                                    Console.ResetColor();
                                }
                                catch (InvalidOption e)
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine(e.getmessage());
                                    Console.ResetColor();
                                }
                            }
                            break;
                        case 7:
                            Console.WriteLine("Enter your account number");
                            c1 = CurrentAccount.findAccount();
                            if (c1 == null)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("Enter valid account number");
                                Console.ForegroundColor = ConsoleColor.White;
                            }
                            else
                                c1.GetAccountDetails();
                            break;
                        case 8:
                            CurrentAccount.GetRateofInterest();
                            break;
                    }
                }
                Console.ReadLine();
                Console.Clear();
            }
        }
    }
}
